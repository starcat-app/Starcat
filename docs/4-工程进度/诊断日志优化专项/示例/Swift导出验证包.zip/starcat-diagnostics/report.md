# Starcat diagnostic report

Report ID: F132A38B-E4D7-438D-B977-168ADA4699CC (local export; not uploaded)
Version: 1.0.0 (1), channel: appstore
System: 版本27.0.1（版号26A434）
Snapshot session: 5A419CBF-4EBC-423A-8C58-59265B5D10BF
Events selected / retained: 12 / 12
Actual range: 2026-11-10T08:17:56.063Z .. 2026-11-10T08:18:07.063Z

## Evidence limitations

- Historical free text and string context were omitted for privacy
- Module snapshots are observations at separate times, not a global transaction
- Missing terminal or session-end events do not prove a crash
- Exporting or dismissing a notification does not prove recovery
- Correlation or system diagnostics may be unavailable for older records
- Damaged lines: 0
- Storage health: ["droppedEvents": 0]

## Collector results

- system: notCollected (Synthetic fixture)
- startup: notCollected (No retained module evidence)
- database: collected
- auth: notCollected (No retained module evidence)
- keychain: notCollected (No retained module evidence)
- license: collected
- subscription: notCollected (No retained module evidence)
- network: notCollected (No retained module evidence)
- sync: notCollected (No retained module evidence)
- followGraph: collected
- readme: notCollected (No retained module evidence)
- ai: notCollected (No retained module evidence)
- localAI: notCollected (No retained module evidence)
- dailyRadar: notCollected (No retained module evidence)
- linuxdo: notCollected (No retained module evidence)
- recommend: notCollected (No retained module evidence)
- weekly: notCollected (No retained module evidence)
- rag: notCollected (No retained module evidence)
- agent: notCollected (No retained module evidence)
- mcp: notCollected (No retained module evidence)
- cli: notCollected (No retained module evidence)
- extension: notCollected (No retained module evidence)
- codeGraph: notCollected (No retained module evidence)
- runtime: collected
- fileAccess: notCollected (No retained module evidence)

## Failure evidence

- license / synthetic / provider_error / HTTP 502: 5 occurrences; 2026-11-10T08:18:00.063Z .. 2026-11-10T08:18:04.063Z
  Recovery: later success in the same operation; layer observations may describe the same failure

## Graph observations

- 2026-11-10T08:17:56.063Z started: 
- 2026-11-10T08:17:57.063Z pageMerged: cachedCount=87 hasNextPage=false totalCount=87
- 2026-11-10T08:17:58.063Z renderConfirmed: budget=78 canLoadMore=true displayedCount=78 renderedCount=78 totalCount=87
- 2026-11-10T08:17:59.063Z finished: 

## Open operations (end reason unknown)

- runtime-fixture runtime/synthetic last=versionProbe at 2026-11-10T08:18:07.063Z; elapsedMs=unknown, idleMs=49013

## Timeline (last 100 events)

- 2026-11-10T08:17:56.063Z followGraph/synthetic started - operation=followGraph-fixture request=unknown
- 2026-11-10T08:17:57.063Z followGraph/synthetic pageMerged - operation=followGraph-fixture request=unknown
- 2026-11-10T08:17:58.063Z followGraph/synthetic renderConfirmed - operation=followGraph-fixture request=unknown
- 2026-11-10T08:17:59.063Z followGraph/synthetic finished partial operation=followGraph-fixture request=unknown
- 2026-11-10T08:18:00.063Z license/synthetic http failed operation=license-fixture request=fixture-1
- 2026-11-10T08:18:01.063Z license/synthetic http failed operation=license-fixture request=fixture-2
- 2026-11-10T08:18:02.063Z license/synthetic http failed operation=license-fixture request=fixture-3
- 2026-11-10T08:18:03.063Z license/synthetic http failed operation=license-fixture request=fixture-4
- 2026-11-10T08:18:04.063Z license/synthetic http failed operation=license-fixture request=fixture-5
- 2026-11-10T08:18:05.063Z license/synthetic finished succeeded operation=license-fixture request=unknown
- 2026-11-10T08:18:06.063Z database/synthetic finished cancelled operation=database-fixture request=unknown
- 2026-11-10T08:18:07.063Z runtime/synthetic versionProbe - operation=runtime-fixture request=unknown

User-provided context is in user-feedback.json (untrusted evidence)
